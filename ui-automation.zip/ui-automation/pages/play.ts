import { Page } from "@playwright/test";
import { MainPage } from "./main-page";
import { CheckOutPage } from "./checkout-page";
import { ListingPage } from "./listing-page";
import { ProductDetailPage } from "./product_detail-page";

export class Play {
    constructor(protected page: Page) {
      this.page = page;
    }
  
    public get mainPage(): MainPage {
      return new MainPage(this.page);
    }
  
    public get checkOutPage(): CheckOutPage {
      return new CheckOutPage(this.page);
    }
  
    public get listingPage(): ListingPage {
      return new ListingPage(this.page);
    }

    public get productDetailPage() :ProductDetailPage{
        return new ProductDetailPage(this.page)
    }
  }