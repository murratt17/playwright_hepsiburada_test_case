import { Page } from "@playwright/test";

export class MainPage {
    constructor(protected page: Page) {
      this.page = page;
    }
  
    searchClickArea = this.page.locator('div').filter({ hasText: /^Ürün, kategori veya marka ara$/ }).first()
    searchBox = this.page.getByPlaceholder('Ürün, kategori veya marka ara');
    searchButton = this.page.getByText('ARA', { exact: true });

  }