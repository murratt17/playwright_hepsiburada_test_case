import { Page } from "@playwright/test";

export class CheckOutPage {
    constructor(protected page: Page) {
      this.page = page;
    }
  
    productName = this.page.locator('//div[@class="product_name_2Klj3"]')
    offeringPrice = this.page.locator('//div[@class="product_price_uXU6Q"]')

  }