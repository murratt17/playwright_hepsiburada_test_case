import { Page } from "@playwright/test";

export class ListingPage {
    constructor(protected page: Page) {
      this.page = page;
    }
  
    brandInput = this.page.locator('(//input[@placeholder="Filtrele"])[1]')
    brandJbl = this.page.locator('//div[text()="JBL"]');

    evaluationScore = this.page.locator('//div[text()="4 yıldız ve üzeri"]');
    usingType = this.page.locator('//*[@id="kullanimtipi"]/label/div[1]');
    onear = this.page.locator('//*[@id="kullanimtipi"]/div/div/div/div/div/div/div/div[2]/label/div/div');

    alignment =  this.page.locator('//div[@class="horizontalSortingBar-rg0Pha8wpDmdnPUKhByO"]//label[1]');
    lowestPrice = this.page.locator('//div[text()="En düşük fiyat"]');

    firstProduct = this.page.locator('(//li[@type="comfort"])[1]');

    

  }