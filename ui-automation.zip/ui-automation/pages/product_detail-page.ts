import { Page } from "@playwright/test";

export class ProductDetailPage {
    constructor(protected page: Page) {
      this.page = page;
    }
  
    productName = this.page.locator('#product-name')
    offeringPrice = this.page.locator('#offering-price')
    addToChart  = this.page.locator('#addToCart')
    goToChart = this.page.locator("//button[text()='Sepete git']");
  }