import { test, expect } from '@playwright/test';

import { Play } from "../pages/play";



test('hepsiburada', async ({ page }) => {
 
  const play = new Play(page);

  await page.goto('/');                                                                     //navigates to www.hepsiburada.com
  await expect(page).toHaveURL('https://www.hepsiburada.com/');                             //checks the url if it is correct
  await play.mainPage.searchClickArea.click();
  await play.mainPage.searchBox.fill("bluetooth kulaklıklar");                              //types 
  await play.mainPage.searchButton.click();                                             
  expect(page.url()).toContain("bluetooth")                                                 //checks the url if it contains bluetooth
  await play.listingPage.brandInput.dblclick();                                             //clicks brand
  await play.listingPage.brandInput.fill("JB");                                             //types JB
  await play.listingPage.brandJbl.click();                                                  //clicks JBL
  await play.listingPage.evaluationScore.click();                                           //clicks the evaluation score 4
  await play.listingPage.onear.click();                                                     //clicks onear
  await page.reload();                                                                      //reloads the page for correct results
  await play.listingPage.alignment.click();                                                 //aligment from lowes price to high
  await play.listingPage.lowestPrice.click();
  await page.reload();
  await play.listingPage.firstProduct.click();                                              //chooses the first product
  await page.waitForTimeout(3000);  
  const openTabs = await page.context().pages()
  await page.goto(openTabs[1].url().toString())
  await openTabs[1].close();                                                                //closes the secondary tab

  const nameOfProductInProductDetailPage = await play.productDetailPage.productName.innerText();   //assigns the productname in product detail page
  const offeringPriceInProductDetailPage = await play.productDetailPage.offeringPrice.innerText(); //assigns the offeringPrice in product detail page

  await play.productDetailPage.addToChart.click();                                          //clicks addToChart
  await play.productDetailPage.goToChart.click();                                           //navigates to Chart
  await expect(page).toHaveURL('https://checkout.hepsiburada.com');

  const nameOfProductInCheckOutPage = await play.checkOutPage.productName.innerText();      //assigns the productname in checkoutPage
  const offeringPriceInCheckOutPage = await play.checkOutPage.offeringPrice.innerText();    //assigns the offeringPrice in checkoutPage

  expect(nameOfProductInProductDetailPage).toEqual(nameOfProductInCheckOutPage);            //compares the product name in detail page with checkout page
  expect(offeringPriceInProductDetailPage).toEqual(offeringPriceInCheckOutPage);            //compares the price in detail page with checkout page

  page.close();

});
  
  
 

